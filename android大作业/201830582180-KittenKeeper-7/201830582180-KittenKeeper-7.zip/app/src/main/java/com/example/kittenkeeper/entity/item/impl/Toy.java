package com.example.kittenkeeper.entity.item.impl;

import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.entity.item.IItem;
import com.example.kittenkeeper.entity.item.ItemType;
import com.example.kittenkeeper.utils.DBUtil;

import org.litepal.annotation.Column;
import org.litepal.crud.LitePalSupport;

/**玩具
 *
 */
public class Toy extends LitePalSupport implements IItem{
    private String name;

    private String description;

    private ItemType type;

    private double happyEffect;

    private double intimacyEffect;

    private int image_id;

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

    @Override
    public String getItemName() {
        return name;
    }

    public Toy(String name, String description, ItemType itemType, double happyEffect) {
        this.name = name;
        this.description = description;
        this.type = itemType;
        this.happyEffect = happyEffect;
    }

    public Toy(ItemType type) {
        this.type = type;
    }

    public ItemType getType() {
        return type;
    }

    public void setType(ItemType type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getHappyEffect() {
        return happyEffect;
    }

    public void setHappyEffect(double happyEffect) {
        this.happyEffect = happyEffect;
    }

    public double getIntimacyEffect() {
        return intimacyEffect;
    }

    public void setIntimacyEffect(double intimacyEffect) {
        this.intimacyEffect = intimacyEffect;
    }

    @Override
    public String getItemDescription() {
        return description;
    }

    @Override
    public void useItem(Kitten kitten, Player player) {
        kitten = DBUtil.getKitten();
        player = DBUtil.getPlayer();
        kitten.setHappy(kitten.getHappy() + happyEffect);
        kitten.setIntimacy(kitten.getIntimacy() + intimacyEffect);
        kitten.save();
        player.save();
    }

    @Override
    public String toString() {
        return "Toy{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", happyEffect=" + happyEffect +
                ", intimacyEffect=" + intimacyEffect +
                '}';
    }
}
