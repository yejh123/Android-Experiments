package com.example.kittenkeeper.customView;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.usage.UsageEvents;
import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.example.kittenkeeper.MainActivity;
import com.example.kittenkeeper.R;
import com.example.kittenkeeper.utils.DBUtil;
import com.example.kittenkeeper.utils.ToastUtil;

import java.io.IOException;
import java.sql.Time;
import java.util.Timer;
import java.util.TimerTask;

import pl.droidsonroids.gif.GifDrawable;
import pl.droidsonroids.gif.GifImageView;

public class KittenImageView extends GifImageView {

    private float X;
    private float Y;
    private float moveX;
    private float moveY;

    private int direction;
    private Timer timer;

    private MainActivity mainActivity;

    //静止状态
    GifDrawable idle;
    //抓取状态
    GifDrawable caught;
    //掉落状态
    GifDrawable fall;
    //进食状态
    GifDrawable eat;
    //饥饿状态
    GifDrawable hungry;
    //死亡状态
    GifDrawable death;
    //治疗状态
    GifDrawable heal;

    AnimatorSet animatorSet;
    ObjectAnimator ainmY;
    ObjectAnimator ainmX;

    public static int BG_LEFT = 1;
    public static int BG_RIGHT = 2;


    public KittenImageView(Context context) {
        super(context);
        mainActivity = (MainActivity)context;
    }

    public KittenImageView(Context context, AttributeSet attrs) throws IOException {
        super(context, attrs);
        setUp(context, attrs);
        mainActivity = (MainActivity)context;
    }

    public KittenImageView(Context context, AttributeSet attrs, int defStyleAttr) throws IOException {
        super(context, attrs, defStyleAttr);
        setUp(context, attrs);
        mainActivity = (MainActivity)context;
    }

    private void setUp(Context context, AttributeSet attrs) throws IOException {
        X = getTranslationX();
        Y = getTranslationY();
        //alive = true;
        timer = new Timer();
        animatorSet = new AnimatorSet();

        idle = new GifDrawable(getResources(), R.raw.lxh_idle);
        caught = new GifDrawable(getResources(), R.raw.lxh_catch);
        eat = new GifDrawable(getResources(), R.raw.eategg);
        fall = new GifDrawable(getResources(),R.raw.down);
        hungry = new GifDrawable(getResources(),R.raw.ill);
        heal = new GifDrawable(getResources(),R.raw.treat);
        death = new GifDrawable(getResources(),R.raw.lxh_death);

    }

    private void setEat() {
        setImageDrawable(eat);
    }

    private void setIdle() {
        setImageDrawable(idle);
    }

    private void setCaught() {
        setImageDrawable(caught);
    }

    private void setFall() {
        setImageDrawable(fall);
    }

    private void setDeath(){setImageDrawable(death);}

    private void setHungry(){setImageDrawable(hungry);}

    private void setHeal(){setImageDrawable(heal);}


    /**点击猫咪时运行该方法
     *
     * @param motionEvent
     */
    public void onTouch(MotionEvent motionEvent) {
        if(!mainActivity.isAlive()) return;
        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (animatorSet.isRunning()) {
                    animatorSet.cancel();
                }
                setCaught();
                moveX = motionEvent.getX();
                moveY = motionEvent.getY();
                break;
            case MotionEvent.ACTION_MOVE:
                float dx = motionEvent.getX() - moveX;
                float dy = motionEvent.getY() - moveY;
                setTranslationX((float) (getTranslationX() + dx));
                setTranslationY((float) (getTranslationY() + dy));
                break;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                if (getTranslationY() < Y - 100) {
                    //切换到下落资源
                    setFall();
                    fallback((float) getTranslationX(), X,
                            (float) getTranslationY(), Y);
                } else {
                    setIdle();
                    climbback((float)getTranslationX(),X,
                            (float)getTranslationY(),Y);
                }
                break;
        }
    }

    public void eat() {
        if(!mainActivity.isAlive()) return;
        setEat();
        Handler Handler = new Handler();
        Handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                setIdle();
            }
        }, getResources().getInteger(R.integer.eat_duration));
    }

    public void heal(){
        setHeal();

        Handler Handler = new Handler();
        Handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                rebirth();
            }
        }, 5000);
    }

    public void dead(){
        setDeath();
        mainActivity.setAlive(false);
    }

    public void rebirth(){
        setIdle();
        String kittenName = "【" + DBUtil.getKitten().getName() + "】";
        ToastUtil.showToast(mainActivity, kittenName + "重新恢复健康");
    }

    /**掉落方法
     * 按下猫咪放松手后自动调用
     * @param currentX 当前X坐标
     * @param X 动画结束终止点X坐标
     * @param currentY 当前Y坐标
     * @param Y 动画结束终止点Y坐标
     */
    private void fallback(float currentX, float X, float currentY, float Y) {
        ainmY = ObjectAnimator.ofFloat(this, "translationY",
                currentY, Y + 300, Y);
        ainmX = ObjectAnimator.ofFloat(this, "translationX",
                currentX, X);


        animatorSet.setDuration(1500);
        animatorSet.playTogether(ainmX, ainmY);
        animatorSet.start();
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {

            }

            @Override
            public void onAnimationEnd(Animator animator) {
                setIdle();
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });
    }

    private void climbback(float currentX, float X, float currentY, float Y) {
        ainmY = ObjectAnimator.ofFloat(this, "translationY",
                currentY, Y);
        ainmX = ObjectAnimator.ofFloat(this, "translationX",
                currentX, X);

        animatorSet.setDuration(1000);
        animatorSet.playTogether(ainmX, ainmY);
        animatorSet.start();
    }
}
