package com.example.kittenkeeper;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.etsy.android.grid.StaggeredGridView;
import com.example.kittenkeeper.entity.item.IItem;
import com.example.kittenkeeper.entity.item.ItemType;
import com.example.kittenkeeper.entity.item.impl.Food;
import com.example.kittenkeeper.entity.item.impl.Medicine;
import com.example.kittenkeeper.entity.item.impl.Toy;
import com.example.kittenkeeper.explore.Exploration;
import com.example.kittenkeeper.utils.ToastUtil;
import com.google.gson.Gson;

import java.util.ArrayList;

public class SelectActivity extends Activity implements AbsListView.OnScrollListener, AbsListView.OnItemClickListener, AdapterView.OnItemLongClickListener, View.OnClickListener {

    private static final String TAG = "StaggeredGridActivity";
    public static final String SAVED_DATA_KEY = "SAVED_DATA";

    private StaggeredGridView mGridView;
    private boolean mHasRequestedMore;
    private ExploreItemsAdapter mAdapter;

    //每个格子的信息
    private static ArrayList<IItem> mData;

    //选中的物品
    private ArrayList<IItem> selected = new ArrayList<>();

    static {
        mData = new ArrayList<>();
        IItem medicine = new Medicine("宠物医疗包", "使用可让您的爱宠瞬间恢复活力，包治百病！", ItemType.MEDICAL_PACKAGE, 50);
        IItem toy = new Toy("逗猫棒", "一种深受猫咪喜爱的玩具。猫咪对快速移动的物体有极大的兴趣，逗猫棒能快速引起猫咪注意，使之兴奋扑咬。",
                ItemType.CAT_TICKET, 10);
        IItem fish = new Food("鱼", "新鲜的一条大鱼，弥漫的腥味让猫咪无法拒绝。", ItemType.FISH, 60);
        IItem catFood = new Food("优质猫粮", "猫粮可锻炼并清洁猫咪牙齿，某种程度上具有口腔保健功效。优质猫粮一般注意营养均衡，能够保证猫咪日常对高等蛋白质及微量元素的需求。",
                ItemType.CAT_FOOD, 80);
        medicine.setImage_id(R.mipmap.medical);
        toy.setImage_id(R.mipmap.toy);
        fish.setImage_id(R.mipmap.fish);
        catFood.setImage_id(R.mipmap.catfood);
        mData.add(medicine);
        mData.add(toy);
        mData.add(fish);
        mData.add(catFood);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select);

        setTitle("Explore");
        mGridView = (StaggeredGridView) findViewById(R.id.grid_view);

        LayoutInflater layoutInflater = getLayoutInflater();

        View header = layoutInflater.inflate(R.layout.explore_list_header, null);
        View footer = layoutInflater.inflate(R.layout.explore_list_footer, null);
        TextView txtHeaderTitle = header.findViewById(R.id.tv_header);
        Button btn_explore_submit = footer.findViewById(R.id.btn_footer);
        btn_explore_submit.setOnClickListener(this);
        txtHeaderTitle.setText("主人，我要去探险了，需要带些什么呢？");
        btn_explore_submit.setText("准备就绪，出发！");

        mGridView.addHeaderView(header);
        mGridView.addFooterView(footer);
        mAdapter = new ExploreItemsAdapter(this, R.id.item_image);

        // do we have saved data?
//        if (savedInstanceState != null) {
//            mData = savedInstanceState.getStringArrayList(SAVED_DATA_KEY);
//        }

        Exploration.startExplore();
        for (IItem data : mData) {
            mAdapter.add(data);
        }

        mGridView.setAdapter(mAdapter);

        //设置滑动监听器
        mGridView.setOnScrollListener(this);

        //设置点击物品监听器
        mGridView.setOnItemClickListener(this);

        //设置长按物品监听器
        mGridView.setOnItemLongClickListener(this);
    }

    public boolean selectItem(int position){
        int selected_max = getResources().getInteger(R.integer.selected_max);
        Log.d(TAG, "selectItem: " + "selected_max: " + selected_max + "selected: " + selected);
        if(selected.size() >= selected_max){
            return false;
        }
        selected.add(mData.get(position));
        return true;
    }

    public void unSelectItem(int position){
        Log.d(TAG, "unSelectItem: " + mData.get(position));
        selected.remove(mData.get(position));
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_sgv_dynamic, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.col1:
//                mGridView.setColumnCount(1);
//                break;
//            case R.id.col2:
//                mGridView.setColumnCount(2);
//                break;
//            case R.id.col3:
//                mGridView.setColumnCount(3);
//                break;
//        }
//        return true;
//    }/

//    @Override
//    protected void onSaveInstanceState(final Bundle outState) {
//        super.onSaveInstanceState(outState);
//        outState.putStringArrayList(SAVED_DATA_KEY, mData);
//    }

    @Override
    public void onScrollStateChanged(final AbsListView view, final int scrollState) {
        Log.d(TAG, "onScrollStateChanged:" + scrollState);
    }

    @Override
    public void onScroll(final AbsListView view, final int firstVisibleItem, final int visibleItemCount, final int totalItemCount) {
        Log.d(TAG, "onScroll firstVisibleItem:" + firstVisibleItem +
                " visibleItemCount:" + visibleItemCount +
                " totalItemCount:" + totalItemCount);

        // 滑动到底会自动加载剩余item
//        if (!mHasRequestedMore) {
//            int lastInScreen = firstVisibleItem + visibleItemCount;
//            if (lastInScreen >= totalItemCount) {
//                Log.d(TAG, "onScroll lastInScreen - so load more");
//                mHasRequestedMore = true;
//                onLoadMoreItems();
//            }
//        }
    }

    private void onLoadMoreItems() {
        final ArrayList<IItem> sampleData = new ArrayList<>(mData);
        for (IItem data : sampleData) {
            mAdapter.add(data);
        }
        // stash all the data in our backing store
        mData.addAll(sampleData);
        // notify the adapter that we can update now
        mAdapter.notifyDataSetChanged();
        mHasRequestedMore = false;
    }

    //点击物品进入物品介绍页面，注意，这里的position从1开始！！！
    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        if(position < 1 || position >= mData.size()){
            return;
        }
        Log.d(TAG, "onItemClick: position: " + position);
        IItem item = mData.get(position-1);

        Intent intent = new Intent(SelectActivity.this, ItemIntroActivity.class);
//        Gson gson = new Gson();
//        String jsonString = gson.toJson(item);
        intent.putExtra("item_name", item.getItemName());
        intent.putExtra("item_description", item.getItemDescription());
        intent.putExtra("item_image_id", item.getImage_id());
        startActivity(intent);

        Toast.makeText(this, "进入" + item.getItemName() + "的详情页面", Toast.LENGTH_SHORT).show();
    }

    //长按物品即选中该物品
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id)
    {
        Toast.makeText(this, "Item Long Clicked: " + position, Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.btn_footer:
                Log.d(TAG, "onClick: " + "btn_footer");
                Toast.makeText(SelectActivity.this, "猫咪出门探险去了！", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(SelectActivity.this, ExploreActivity.class);

                Exploration.setItems(selected);

                startActivity(intent);
                break;

        }
    }
}
