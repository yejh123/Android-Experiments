package com.example.kittenkeeper;


import android.content.Context;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import com.etsy.android.grid.util.DynamicHeightImageView;
import com.etsy.android.grid.util.DynamicHeightTextView;
import com.example.kittenkeeper.entity.item.IItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;


/***
 * ADAPTER
 */

public class ExploreItemsAdapter extends ArrayAdapter<IItem> {

    private static final String TAG = "ExploreItemsAdapter";

    static class ViewHolder {
        DynamicHeightImageView item_image;
        Button btn_select;
    }

    private final LayoutInflater mLayoutInflater;
    //用于获取随机高度
    private final Random mRandom;
    //格子颜色
    private final ArrayList<Integer> mBackgroundColors;

    private SelectActivity mContext;
    //标记是否选中
    private Map<IItem, Boolean> selected;

    private static final SparseArray<Double> sPositionHeightRatios = new SparseArray<>();

    public ExploreItemsAdapter(final Context context, final int textViewResourceId) {
        super(context, textViewResourceId);
        mContext = (SelectActivity) context;
        mLayoutInflater = LayoutInflater.from(context);
        mRandom = new Random();
        mBackgroundColors = new ArrayList<>();
        mBackgroundColors.add(R.color.orange);
        mBackgroundColors.add(R.color.green);
        mBackgroundColors.add(R.color.blue);
        mBackgroundColors.add(R.color.yellow);
        mBackgroundColors.add(R.color.grey);
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {

        final ViewHolder vh;
        if (convertView == null) {
            convertView = mLayoutInflater.inflate(R.layout.explore_list_item, parent, false);
            vh = new ViewHolder();
            vh.item_image = (DynamicHeightImageView) convertView.findViewById(R.id.item_image);
            vh.btn_select = (Button) convertView.findViewById(R.id.btn_select);

            convertView.setTag(vh);
        } else {
            vh = (ViewHolder) convertView.getTag();
        }

        double positionHeight = getPositionRatio(position);
        int backgroundIndex = position >= mBackgroundColors.size() ?
                position % mBackgroundColors.size() : position;

        convertView.setBackgroundResource(mBackgroundColors.get(backgroundIndex));

        Log.d(TAG, "getView position:" + position + " h:" + positionHeight);

        //设置随机高度
        vh.item_image.setHeightRatio(positionHeight);
        vh.item_image.setImageResource(getItem(position).getImage_id());

        if (selected == null) {
            selected = new HashMap<>();
        }
        final IItem iItem = getItem(position);
        selected.put(iItem, false);

        vh.btn_select.setTag(R.mipmap.unselected);
        vh.btn_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                if (!selected.get(iItem)) {
                    if (mContext.selectItem(position)) {
                        Toast.makeText(getContext(), "您选择了【" + iItem.getItemName() + "】", Toast.LENGTH_SHORT).show();
                        vh.btn_select.setBackgroundResource(R.mipmap.selected);
                        selected.put(iItem, true);
                    } else {
                        Toast.makeText(getContext(), "只能选择最多" + mContext.getResources().getInteger(R.integer.selected_max) + "件物品哦！", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    mContext.unSelectItem(position);
                    vh.btn_select.setBackgroundResource(R.mipmap.unselected);
                    selected.put(iItem, false);
                }
            }
        });

        return convertView;
    }

    private double getPositionRatio(final int position) {
        double ratio = sPositionHeightRatios.get(position, 0.0);
        // if not yet done generate and stash the columns height
        // in our real world scenario this will be determined by
        // some match based on the known height and width of the image
        // and maybe a helpful way to get the column height!
        if (ratio == 0) {
            ratio = getRandomHeightRatio();
            sPositionHeightRatios.append(position, ratio);
            Log.d(TAG, "getPositionRatio:" + position + " ratio:" + ratio);
        }
        return ratio;
    }

    private double getRandomHeightRatio() {
        return (mRandom.nextDouble() / 2.0) + 1.0; // height will be 1.0 - 1.5 the width
    }
}