package com.example.kittenkeeper.behavior;

import android.content.Context;

import com.example.kittenkeeper.R;
import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;

import static java.lang.Math.*;

/**
 * 行为类：封装了玩家与猫咪的互动行为
 */
public class Behavior {
    private Context mContext;

    public Behavior(Context context){
        this.mContext = context;
    }

    //喂食
    public void feed(Kitten kitten, Player player) {
        //业务逻辑实现
        if (player.getFood() != 0 && kitten.getHungry() != 100) {
            player.setFood(player.getFood() - 1);
            if (kitten.getHungry() < 40) {
                kitten.setHungry(max(40.0, 1.6 * kitten.getHungry()));
            } else {
                kitten.setHungry(min(100.0, 1.6 * kitten.getHungry()));
            }
            kitten.save();
            player.save();
        }
    }

    public void feed(Kitten kitten, Player player, int hungryIncrease) {
        kitten.setHungry(min(100, kitten.getHungry() + hungryIncrease));
        kitten.save();
        player.save();
    }

    //玩耍
    public void play(Kitten kitten, Player player) {
        //业务逻辑实现
        kitten.setHappy(min(100, kitten.getHappy() +  mContext.getResources().getInteger(R.integer.play_happy_increase)));
        kitten.setIntimacy(kitten.getIntimacy() + mContext.getResources().getInteger(R.integer.play_intimacy_increase));
        player.setHeart(player.getHeart() + 1);
        kitten.save();
        player.save();

    }

    //治疗
    public void heal(Kitten kitten, Player player, int heelIncrease) {
        kitten.setHealth(min(100, kitten.getHealth() + heelIncrease));
        kitten.save();
        player.save();
    }


}
