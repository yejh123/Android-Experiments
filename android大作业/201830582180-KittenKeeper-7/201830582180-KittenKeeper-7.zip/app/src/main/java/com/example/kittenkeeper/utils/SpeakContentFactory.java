package com.example.kittenkeeper.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class SpeakContentFactory {
    private static List<String> speaks;
    static {
        speaks = new ArrayList<>();
        speaks.add("主人，你知道吗，如果这个游戏有坠落伤害的话，我可能已经挂了喵~~~");
        speaks.add("主人要多喝热水哦喵~~~");
        speaks.add("如果创建我的程序员更厉害的话，可能我说的话就不会重复了喵~~~");
        speaks.add("喵~~~");
        speaks.add("什么~喵~？sh160了喵~？");
        speaks.add("主人，你知道吗喵~，曾经有个人给我取名叫做【小狗\uD83D\uDC36】");
        speaks.add("愿这个世界没有薛定谔喵~~~");
        speaks.add("我爱你主人，喵~~~！");
        speaks.add("主人，你能猜出来我的原型是哪一只猫吗喵~~~");
        speaks.add("主人，一定不要抛弃我555\no(╥﹏╥)o");
        speaks.add("主人～饿～饿～真的饿～快做饭～你磨叽啥呢快点快点～～～喵受不了啦～～");
        speaks.add("嗷呜要抱抱还要举高高～唔抱抱好舒服,就是这里再挠挠再挠挠噜噜噜……");
        speaks.add("主人，其实，在你切屏的时候，我在你床上撒尿了喵~~~");
        speaks.add("今天晚饭吃什么呢喵~~~");
        speaks.add("主人，你在干什么呢喵~~~");

    }

    public static String getRandomSpeakContent(){
        Random random = new Random();
        return speaks.get(random.nextInt(speaks.size()));
    }
}
