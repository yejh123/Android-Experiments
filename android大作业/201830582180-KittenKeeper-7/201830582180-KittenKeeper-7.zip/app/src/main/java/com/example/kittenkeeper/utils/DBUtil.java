package com.example.kittenkeeper.utils;

import android.util.Log;

import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;

import org.litepal.LitePal;

import java.util.Date;
import java.util.List;


/**
 * 数据库工具类
 * 获取玩家对象和猫咪对象
 */
public class DBUtil {
    private static String TAG = "DBUtil";

    public static Player getPlayer(){
        List<Player> players = LitePal.limit(1).find(Player.class);
        Player player = null;
        if(players.isEmpty()){
            player = new Player();
            player.setFood(1000);
            player.setMoney(500);
            player.save();
        }else{
            player = players.get(0);
        }
        return player;
    }

    public static Kitten getKitten(){
        List<Kitten> kittens = LitePal.order("time desc").limit(1).find(Kitten.class);
        Kitten kitten = null;
        if(kittens.isEmpty()){
            kitten = new Kitten();
            kitten.setHealth(100);
            kitten.setIntimacy(0);
            kitten.setHappy(80);
            kitten.setHungry(100);
            kitten.setBirthDay(new Date());
            kitten.setTime(new Date());
            kitten.save();
        }
        else{
            kitten = kittens.get(0);
        }
        Log.d(TAG, "getKitten: " + kitten);
        return kitten;
    }

}
