package com.example.kittenkeeper.explore;

import java.util.List;

/**
 * 随机事件类
 * 进入探险模式时随机触发
 */

public class Event {
    //事件标题
    private String eventTitle;

    //事件内容
    private String eventContent;

    //事件的应对选项
    private List<EventChoice> choices;

    //事件图片
    private int event_image_id;

    public Event(String eventTitle, String eventContent, List<EventChoice> choices) {
        this.eventTitle = eventTitle;
        this.eventContent = eventContent;
        this.choices = choices;
    }

    public Event(String eventTitle, String eventContent, List<EventChoice> choices, int event_image_id) {
        this.eventTitle = eventTitle;
        this.eventContent = eventContent;
        this.choices = choices;
        this.event_image_id = event_image_id;
    }

    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getEventContent() {
        return eventContent;
    }

    public void setEventContent(String eventContent) {
        this.eventContent = eventContent;
    }

    public List<EventChoice> getChoices() {
        return choices;
    }

    public void setChoices(List<EventChoice> choices) {
        this.choices = choices;
    }

    public int getEvent_image_id() {
        return event_image_id;
    }

    public void setEvent_image_id(int event_image_id) {
        this.event_image_id = event_image_id;
    }

    @Override
    public String toString() {
        return "Event{" +
                "eventTitle='" + eventTitle + '\'' +
                ", eventContent='" + eventContent + '\'' +
                ", choices=" + choices +
                ", event_image_id=" + event_image_id +
                '}';
    }
}
