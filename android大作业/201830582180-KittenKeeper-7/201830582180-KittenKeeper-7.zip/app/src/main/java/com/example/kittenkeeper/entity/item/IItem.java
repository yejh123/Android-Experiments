package com.example.kittenkeeper.entity.item;

import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.utils.DBUtil;

/**物品接口
 *
 */
public interface IItem {
    String getItemName();

    String getItemDescription();

    void useItem(Kitten kitten, Player player);

    ItemType getType();

    void setImage_id(int image_id);

    int getImage_id();
}
