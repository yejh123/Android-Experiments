package com.example.kittenkeeper.entity.item.impl;

import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.entity.item.IItem;
import com.example.kittenkeeper.entity.item.ItemType;
import com.example.kittenkeeper.utils.DBUtil;

import org.litepal.annotation.Column;

public class Food implements IItem {
    private String name;

    private ItemType type;

    private String description;

    private double happyEffect;

    private double hungryEffect;

    private double intimacyEffect;

    private double healthEffect;

    private int image_id;

    public int getImage_id() {
        return image_id;
    }

    public void setImage_id(int image_id) {
        this.image_id = image_id;
    }

    public ItemType getType() {
        return type;
    }

    public void setType(ItemType type) {
        this.type = type;
    }

    public Food(ItemType type) {
        this.type = type;
    }

    public Food(String name, String description, ItemType itemType, double hungryEffect) {

        this.name = name;
        this.description = description;
        this.type = itemType;
        hungryEffect = hungryEffect;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getHappyEffect() {
        return happyEffect;
    }

    public void setHappyEffect(double happyEffect) {
        this.happyEffect = happyEffect;
    }

    public double getHungryEffect() {
        return hungryEffect;
    }

    public void setHungryEffect(double hungryEffect) {
        this.hungryEffect = hungryEffect;
    }

    public double getIntimacyEffect() {
        return intimacyEffect;
    }

    public void setIntimacyEffect(double intimacyEffect) {
        this.intimacyEffect = intimacyEffect;
    }

    public double getHealthEffect() {
        return healthEffect;
    }

    public void setHealthEffect(double healthEffect) {
        this.healthEffect = healthEffect;
    }

    @Override
    public String toString() {
        return "Food{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", happyEffect=" + happyEffect +
                ", HungryEffect=" + hungryEffect +
                ", intimacyEffect=" + intimacyEffect +
                ", healthEffect=" + healthEffect +
                '}';
    }

    @Override
    public String getItemName() {
        return name;
    }

    @Override
    public String getItemDescription() {
        return description;
    }

    @Override
    public void useItem(Kitten kitten, Player player) {
        kitten = DBUtil.getKitten();
        player = DBUtil.getPlayer();
        kitten.setHappy(kitten.getHappy() + happyEffect);
        kitten.setIntimacy(kitten.getIntimacy() + intimacyEffect);
        kitten.setHungry(kitten.getHungry() + hungryEffect);
        kitten.setHealth(kitten.getHealth() + healthEffect);
    }
}
