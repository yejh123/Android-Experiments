package com.example.kittenkeeper.service;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.widget.ProgressBar;

import androidx.core.app.NotificationCompat;

import com.example.kittenkeeper.MainActivity;
import com.example.kittenkeeper.R;
import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.utils.DBUtil;

import org.litepal.LitePal;
import org.litepal.crud.LitePalSupport;

import java.io.IOException;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
public class ForegroundService extends Service {

    public ForegroundService() {

    }
    private KittenBinder  mBinder = new KittenBinder();

    public IBinder onBind(Intent intent) {
        return mBinder;
    }
    public class KittenBinder extends Binder {

    }

    @Override


    public void onCreate() {
        super.onCreate();
        //前台服务
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent, 0);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(R.mipmap.lxh_idle1);
        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(), R.mipmap.lxh_idle1));
        builder.setContentTitle("KittenKeeper");
        builder.setContentText("Welcome to KittenKeeper.");
        builder.setWhen(System.currentTimeMillis());
        builder.setDefaults(NotificationCompat.DEFAULT_ALL);
        builder.setContentIntent(pi);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            builder.setChannelId("notification_id");
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            NotificationChannel channel = new NotificationChannel("notification_id", "notification_name", NotificationManager.IMPORTANCE_LOW);
            notificationManager.createNotificationChannel(channel);
        }
        startForeground(1, builder.build());

    }

    public int onStartCommand(Intent intent,int flags,int startId){
        return super.onStartCommand(intent,flags,startId);
    }

    public void onDestroy(){
        super.onDestroy();
    }
}



