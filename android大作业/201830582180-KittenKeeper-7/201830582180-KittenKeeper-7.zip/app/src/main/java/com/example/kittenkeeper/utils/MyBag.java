package com.example.kittenkeeper.utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

import com.example.kittenkeeper.MainActivity;
import com.example.kittenkeeper.R;
import com.example.kittenkeeper.behavior.Behavior;
import com.example.kittenkeeper.customView.KittenImageView;
import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.nightonke.boommenu.BoomButtons.OnBMClickListener;
import com.nightonke.boommenu.BoomButtons.TextOutsideCircleButton;
import com.nightonke.boommenu.BoomMenuButton;
import com.nightonke.boommenu.Util;

import java.util.logging.Handler;
import java.util.logging.LogRecord;


public class MyBag {
    /**
     * 背包数据
     */
    private static int index = 0;
    private KittenImageView kittenImageView;
    private Behavior behavior;
    private Context mContext;

    static String getext() {
        if (index >= text.length) index = 0;
        return text[index++];
    }
    private static String [] text = new String[]{"猫粮","医疗箱","鱼","玩具"};

    private static int imageResourceIndex = 0;

    static int getImageResource() {
        if (imageResourceIndex >= imageResources.length) imageResourceIndex = 0;
        return imageResources[imageResourceIndex++];
    }
    private static int[] imageResources = new int[]{
            R.mipmap.catfood,
            R.mipmap.medical,
            R.mipmap.fish,
            R.mipmap.toy
    };

    public MyBag(final Context context, final KittenImageView kittenImageView, final Behavior behavior)
    {
        final MainActivity mainActivity = (MainActivity)context;
        this.kittenImageView = kittenImageView;
        this.behavior = behavior;
        this.mContext = context;
        //背包初始化
        BoomMenuButton boomMenuButton = mainActivity.findViewById(R.id.bmb);
        for (int i = 0; i < boomMenuButton.getPiecePlaceEnum().pieceNumber(); i++) {
            TextOutsideCircleButton.Builder builder = new TextOutsideCircleButton.Builder()
                    .listener(new OnBMClickListener() {
                        @Override
                        public void onBoomButtonClick(int index) {
                            //Toast.makeText(activity, "Clicked " + text[index], Toast.LENGTH_SHORT).show();
                            Kitten kitten = DBUtil.getKitten();
                            Player player = DBUtil.getPlayer();
                            switch (index){
                                case 0:
                                    eat(kitten, player, mainActivity.getResources().getInteger(R.integer.catFood_hungry_increase));
                                    break;
                                case 1:
                                    heal(kitten, player, mainActivity.getResources().getInteger(R.integer.medical_package_heal));
                                    break;
                                case 2:
                                    eat(kitten, player, mainActivity.getResources().getInteger(R.integer.fish_hungry_increase));
                                    break;
                                case 3:
                                    ToastUtil.showToast(mainActivity, "敬请期待");
                                    break;
                            }
                        }
                    })
                    .normalImageRes(getImageResource())
                    .normalText(getext())
                    .isRound(false)
                    .shadowCornerRadius(Util.dp2px(15))
                    .buttonCornerRadius(Util.dp2px(15));
            boomMenuButton.addBuilder(builder);
        }
    }

    private void eat(Kitten kitten, Player player, int hungryUp){
        final MainActivity mainActivity = (MainActivity)mContext;
        if(!mainActivity.isAlive()){
            ToastUtil.showToast(mainActivity, kitten.getName() + "急需治疗");
            return;
        }
        if(mainActivity.isAlreadyEat()){
            ToastUtil.showToast(mainActivity, kitten.getName() + "才刚刚吃饱哦！");
            return;
        }
        ToastUtil.showToast(mainActivity, kitten.getName() + "饱食度上升了！");
        kitten = DBUtil.getKitten();
        player = DBUtil.getPlayer();
        behavior.feed(kitten, player, hungryUp);
        kittenImageView.eat();
        mainActivity.updateData();
        kitten = DBUtil.getKitten();
        if(kitten.getHungry() >= 95){
            mainActivity.setAlreadyEat(true);
            new Thread(){
                @Override
                public void run() {
                    try {
                        sleep(mainActivity.getResources().getInteger(R.integer.eat_cool));
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } finally {
                        mainActivity.setAlreadyEat(false);
                    }
                }
            }.start();
        }
    }

    private void heal(Kitten kitten, Player player, int healUp){
        final MainActivity mainActivity = (MainActivity)mContext;
        if(kitten.getHealth() > 95){
            ToastUtil.showToast(mainActivity, kitten.getName() + "很健康，不需要治疗");
            return;
        }
        if(!mainActivity.isAlive()){
            kittenImageView.rebirth();
            mainActivity.setAlive(true);
        }else{
            ToastUtil.showToast(mainActivity, kitten.getName() + "健康值上升了");
        }

        kittenImageView.heal();
        behavior.heal(kitten, player, healUp);
        mainActivity.updateData();

    }
}