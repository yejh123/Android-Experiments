package com.example.kittenkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.kittenkeeper.entity.item.IItem;
import com.google.gson.Gson;

import org.w3c.dom.Text;

public class ItemIntroActivity extends AppCompatActivity {
    public final static String TAG = "ItemIntroActivity";
    private ImageView image;
    private TextView title;
    private TextView content;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_intro);
        init();
    }

    private void init() {
        image = findViewById(R.id.item_info_image);
        title = findViewById(R.id.item_info_title);
        content = findViewById(R.id.item_info_content);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        image.setImageResource(extras.getInt("item_image_id"));
        title.setText(extras.getString("item_name"));
        content.setText(extras.getString("item_description"));

    }
}
