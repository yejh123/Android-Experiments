package com.example.kittenkeeper;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.view.MotionEvent;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.kittenkeeper.behavior.Behavior;
import com.example.kittenkeeper.customLayout.BubbleLayout;
import com.example.kittenkeeper.customView.CoolImageView;
import com.example.kittenkeeper.customView.KittenImageView;
import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.service.ForegroundService;
import com.example.kittenkeeper.utils.DBUtil;
import com.example.kittenkeeper.utils.Introduction;
import com.example.kittenkeeper.utils.MyBag;
import com.example.kittenkeeper.utils.MyDialog;
import com.example.kittenkeeper.utils.SpeakContentFactory;
import com.example.kittenkeeper.utils.ToastUtil;

import org.litepal.LitePal;

import java.lang.ref.WeakReference;
import java.util.Timer;
import java.util.TimerTask;

/**
 * 每次打开app
 * 开启服务：定时器
 * 绑定服务
 * <p>
 * <p>
 * 定时器时间到：
 * 1、判断当前是否绑定了服务
 * 如果没有，直接更新数据，记得调用save()
 * 如果有，更新数据 + 更新页面数据
 * <p>
 * <p>
 * 每次关闭app
 * 解除绑定
 */
public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnTouchListener {

    private Kitten kitten;
    private Player player;
    private Behavior behavior;
    private TextView text_hungry, text_happy, text_intimacy, text_food, text_heart;
    //private CoolImageView bg_image;
    private ImageView bg_image;
    private KittenImageView pet_image;
    //private boolean isLeft = true;

    //处理器
    private static Handler hungryHandler;
    private static Handler intimacyHandler;
    private static Handler healthHandler;
    private static Handler speakHandler;

    //定时器
    private Timer hungryTimer;
    private Timer intimacyTimer;
    private Timer healthTimer;
    private Timer speakTimer;

    private boolean alreadyEat = false;
    private boolean alreadyPlay = false;
    private boolean isAlive = true;
    private ForegroundService.KittenBinder mBinder;
    private final static String TAG = "MainActivity";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //开启服务
        Intent startIntent = new Intent(this, ForegroundService.class);
        startService(startIntent);

        //绑定服务，一旦用户解除绑定或者停止了这个Activity，Service也自动停止了
        Intent bindIntent = new Intent(this, ForegroundService.class);
        bindService(new Intent(this, ForegroundService.class), connection, BIND_AUTO_CREATE);


        //隐藏标题栏
        getSupportActionBar().hide();

        //使用LitePal管理数据库
        LitePal.initialize(this);

        //初始化
        init();

        //初始化定时器
        initTimer();

        //初始化背包
        MyBag myBag = new MyBag(MainActivity.this, pet_image, behavior);


    }


    public void init() {
        kitten = DBUtil.getKitten();
        player = DBUtil.getPlayer();
        behavior = new Behavior(MainActivity.this);
        Log.d("MainActivity", "猫咪状态：" + kitten);
        Log.d("MainActivity", "player状态：" + player);
        //初始化背景左右移动按钮
        Button btn_to_right = findViewById(R.id.btn_to_right);
        Button btn_to_left = findViewById(R.id.btn_to_left);
        bg_image = findViewById(R.id.background);
        btn_to_left.setOnClickListener(this);
        btn_to_right.setOnClickListener(this);

        Button btn_explore = findViewById(R.id.exploreIcon);
        btn_explore.setOnClickListener(this);


        //初始化kitten的动画实例
        pet_image = (KittenImageView) findViewById(R.id.pet);
        pet_image.setOnTouchListener(this);

        text_hungry = findViewById(R.id.hungry);
        text_happy = findViewById(R.id.happy);
        text_intimacy = findViewById(R.id.intimacy);
        text_food = findViewById(R.id.food);
        text_heart = findViewById(R.id.heart);

        Button btn_food = findViewById(R.id.foodIcon);
        btn_food.setOnClickListener(this);

        Button btn_hungry = findViewById(R.id.hungryIcon);
        btn_hungry.setOnClickListener(this);

        Button btn_happy = findViewById(R.id.happyIcon);
        btn_happy.setOnClickListener(this);

        Button btn_intimacy = findViewById(R.id.intimacyIcon);
        btn_intimacy.setOnClickListener(this);

        Button btn_heart = findViewById(R.id.heartIcon);
        btn_heart.setOnClickListener(this);

        Button btn_rename = findViewById(R.id.btn_rename);
        btn_rename.setOnClickListener(this);

        Button btn_tip = findViewById(R.id.btn_tip);
        btn_tip.setOnClickListener(this);
    }

    private static class HungryHandler extends Handler {
        private final MainActivity mActivity;

        public HungryHandler(MainActivity activity) {
            mActivity = activity;
        }

        @Override
        public void handleMessage(Message msg) {
            Kitten kitten = DBUtil.getKitten();
            if (msg.what == 0) {
                if (0 < kitten.getHungry()) {
                    kitten.setHungry(kitten.getHungry() - 1);
                } else {

                    kitten.setHungry(0);

                }
                if (0 < kitten.getHappy()) {
                    kitten.setHappy(kitten.getHappy() - 1);
                } else {
                    kitten.setHappy(0);
                }


                kitten.save();
                mActivity.updateData();
            }
        }
    }

    private static class IntimacyHandler extends Handler {
        private final MainActivity mActivity;

        public IntimacyHandler(MainActivity activity) {
            mActivity = activity;
        }

        @Override
        public void handleMessage(Message msg) {
            Kitten kitten = DBUtil.getKitten();
            kitten = DBUtil.getKitten();
            if (msg.what == 1) {
                if (0 < kitten.getIntimacy()) {
                    kitten.setIntimacy(kitten.getIntimacy() - 1);
                } else {
                    kitten.setIntimacy(0);
                }
                kitten.save();
                mActivity.updateData();
            }
        }
    }

    private static class HealthHandler extends Handler {
        private final MainActivity mActivity;
        private KittenImageView pet_image;

        public HealthHandler(MainActivity activity, KittenImageView pet_image) {
            mActivity = activity;
            this.pet_image = pet_image;
        }

        @Override
        public void handleMessage(Message msg) {
            Kitten kitten = DBUtil.getKitten();
            if (msg.what == 2) {
                if (kitten.getHungry() < 20) {
                    if (0 < kitten.getHealth()) {
                        kitten.setHealth(kitten.getHealth() - 1);
                    } else {
                        pet_image.dead();
                        kitten.setHealth(0);
                    }
                }
                kitten.save();
                //player.save();
                mActivity.updateData();
            }
        }
    }

    private static class SpeakHandler extends Handler {
        private final MainActivity mActivity;

        public SpeakHandler(MainActivity activity) {
            mActivity = activity;
        }

        @Override
        public void handleMessage(Message msg) {
            if (msg.what == 3 && mActivity.isAlive()) {
                String speakContent = SpeakContentFactory.getRandomSpeakContent();
                mActivity.speak(speakContent);
            }
        }
    }

    public void initTimer() {
        //计时器实现Hungry,Health...减小
        //计时器实现Hungry,Health...减小
        hungryHandler = new HungryHandler(MainActivity.this);
        hungryTimer = new Timer();
        hungryTimer.schedule(new TimerTask() {
            public void run() {
                hungryHandler.sendEmptyMessage(0);
            }
        }, 0, getResources().getInteger(R.integer.happy_decrease_cool));

        intimacyHandler = new IntimacyHandler(MainActivity.this);
        intimacyTimer = new Timer();
        intimacyTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                intimacyHandler.sendEmptyMessage(1);
            }
        }, 0, getResources().getInteger(R.integer.intimacy_decrease_cool));

        healthHandler = new HealthHandler(MainActivity.this, pet_image);
        healthTimer = new Timer();
        healthTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                healthHandler.sendEmptyMessage(2);
            }
        }, 0, getResources().getInteger(R.integer.health_decrease_cool));

        speakHandler = new SpeakHandler(MainActivity.this);
        speakTimer = new Timer();
        speakTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                speakHandler.sendEmptyMessage(3);
            }
        }, 0, getResources().getInteger(R.integer.speak_cool));

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        hungryTimer.cancel();
        intimacyTimer.cancel();
        healthTimer.cancel();
        speakTimer.cancel();
    }

    public void updateData() {
        kitten = DBUtil.getKitten();
        if (kitten == null) {
            return;
        }
        text_hungry.setText("" + (int) kitten.getHungry());
        text_happy.setText("" + (int) kitten.getHappy());
        text_intimacy.setText("" + (int) kitten.getIntimacy());
        text_food.setText("" + player.getFood());
        text_heart.setText("" + (int) kitten.getHealth());
    }

    //kitten被拖动
    public boolean onTouch(View view, MotionEvent motionEvent) {
        pet_image.onTouch(motionEvent);
        //每过一段时间点击猫咪才会增加亲密度
        if (!alreadyPlay) {
            System.out.println(alreadyPlay);
            if (motionEvent.getAction() == motionEvent.ACTION_UP) {
                kitten = DBUtil.getKitten();
                player = DBUtil.getPlayer();
                behavior.play(kitten, player);
                updateData();
                Toast.makeText(MainActivity.this, "猫咪的兴奋度和亲密度增加了", Toast.LENGTH_SHORT).show();
                alreadyPlay = true;
                new Thread() {
                    @Override
                    public void run() {
                        try {
                            sleep(getResources().getInteger(R.integer.play_cool));
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } finally {
                            alreadyPlay = false;
                        }
                    }
                }.start();
            }
        }
        return true;
    }

    //kitten讲话
    public void speak(String str) {
        final BubbleLayout bubbleLayout = findViewById(R.id.bubble);
        TextView text_bubble = findViewById(R.id.bubble_text);
        text_bubble.setText(str);
        bubbleLayout.setVisibility(View.VISIBLE);
        Handler Handler = new Handler();
        Handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                bubbleLayout.setVisibility(View.INVISIBLE);
            }
        }, getResources().getInteger(R.integer.speak_duration));
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_to_left:
                speak("test");
                break;
//            case R.id.btn_to_right:
//                if (isLeft) {
//                    bg_image.startMove(pet_image);
//                    pet_image.move(200, pet_image.getTranslationY(), 1500, pet_image.BG_RIGHT);
//                    isLeft = false;
//                }
//                break;
            case R.id.foodIcon:
                if (alreadyEat) {
                    ToastUtil.showToast(MainActivity.this, kitten.getName() + "才刚刚吃饱哦！");
                    return;
                }
                ToastUtil.showToast(MainActivity.this, kitten.getName() + "饱食度上升了！");
                kitten = DBUtil.getKitten();
                player = DBUtil.getPlayer();
                behavior.feed(kitten, player);
                pet_image.eat();
                updateData();
                kitten = DBUtil.getKitten();
                if (kitten.getHungry() == 100) {
                    alreadyEat = true;
                    new Thread() {
                        @Override
                        public void run() {
                            try {
                                sleep(1000 * 30);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            } finally {
                                alreadyEat = false;
                            }
                        }
                    }.start();
                }
                break;
            case R.id.exploreIcon:
                //pet_image.move(pet_image.getTranslationX(), pet_image.getTranslationY(), 100, KittenImageView.WALK_RIGHT);
                kitten = DBUtil.getKitten();
                if (kitten.getHungry() < 80 || kitten.getHealth() < 80) {
                    ToastUtil.showToast(MainActivity.this, "【" + kitten.getName() + "】饱食度或健康值过低，无法进行探险");
                    return;
                }
                Intent intent = new Intent(MainActivity.this, SelectActivity.class);
                startActivity(intent);
                break;
            case R.id.hungryIcon:
                MyDialog.showDialog(MainActivity.this, Introduction.HUNGRY_INTRODUCTION, Introduction.HUNGRY_DESCRIPTION);
                break;
            case R.id.happyIcon:
                MyDialog.showDialog(MainActivity.this, Introduction.HAPPY_INTRODUCTION, Introduction.HAPPY_DESCRIPTION);
                break;
            case R.id.intimacyIcon:
                MyDialog.showDialog(MainActivity.this, Introduction.INTIMACY_INTRODUCTION, Introduction.INTIMACY_DESCRIPTION);
                break;
            case R.id.heartIcon:
                MyDialog.showDialog(MainActivity.this, Introduction.HEART_INTRODUCTION, Introduction.HEART_DESCRIPTION);
                break;
            case R.id.btn_rename:
                MyDialog.showSettingDialog(MainActivity.this);
                break;
            case R.id.btn_tip:
                MyDialog.showDialog(MainActivity.this, Introduction.TIP_INTRODUCTION, Introduction.TIP_DESCRIPTION);
                break;

        }
    }

    private ServiceConnection connection = new ServiceConnection() {
        @Override
        //活动绑定时调用
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBinder = (ForegroundService.KittenBinder) service;

        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {

        }
    };


    public boolean isAlreadyEat() {
        return alreadyEat;
    }

    public void setAlreadyEat(boolean alreadyEat) {
        this.alreadyEat = alreadyEat;
    }

    public boolean isAlreadyPlay() {
        return alreadyPlay;
    }

    public void setAlreadyPlay(boolean alreadyPlay) {
        this.alreadyPlay = alreadyPlay;
    }

    public boolean isAlive() {
        return isAlive;
    }

    public void setAlive(boolean alive) {
        isAlive = alive;
    }
}