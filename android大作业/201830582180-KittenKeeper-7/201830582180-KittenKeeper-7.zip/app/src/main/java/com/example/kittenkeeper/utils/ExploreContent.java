package com.example.kittenkeeper.utils;

@Deprecated
public class ExploreContent {
    public static final String []EXPLORETITLE = new String[]{"偶遇怪物","山洞探险"};
    public static final String []EXPLORECONTENT = new String[]{"偶遇怪物，需要做出你的选择\n偶遇怪物，需要做出你的选择\n偶遇怪物，需要做出你的选择" ,
            "可以选择一个山洞进去淘宝\n可以选择一个山洞进去淘宝\n可以选择一个山洞进去淘宝"};
    public static final String[][]EXPLORECHOISE = new String[][]{{"攻击","逃跑","装死","忽略"},
        {"进入山洞1","进入山洞2","进入山洞3","不进入山洞"}};
}
