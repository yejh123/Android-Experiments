package com.example.kittenkeeper.entity.item;

public enum  ItemType {
    FISH, CAT_FOOD, MEDICAL_PACKAGE, CAT_TICKET;
}
