package com.example.kittenkeeper.explore;

import com.example.kittenkeeper.entity.item.IItem;
import com.example.kittenkeeper.entity.item.ItemType;
import com.example.kittenkeeper.entity.item.impl.Food;
import com.example.kittenkeeper.entity.item.impl.Toy;
import com.example.kittenkeeper.utils.DBUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class EventFactory {

    private static List<Event> events;


    //随机事件
    static {
        String kittenName = DBUtil.getKitten().getName();
        String decoratedName = "【" + kittenName + "】";
        events = new ArrayList<>();
        hasHappened = new ArrayList<>();

        //随机事件1
        List<EventChoice> choices1 = new ArrayList<>();
        choices1.add(new EventChoice("一条鱼", null, "获得了一条新鲜的鱼！"));
        choices1.add(new EventChoice("一个医疗包", null, "获得了一个医疗包！"));
        choices1.add(new EventChoice("一份猫粮", null, "获得了一份猫粮！"));
        choices1.add(new EventChoice("一个猫咪玩具", null, "获得了一个逗猫棒！"));
        Event event1 = new Event("恭喜你，猫神下凡！", "猫神遇到您的猫咪【" +
                kittenName + "】 ，甚是喜欢，于是当场决定送给【" + kittenName +
                "】一份大礼，【" + kittenName + "】很开心地选择了：", choices1);
        events.add(event1);

        //随机事件2
        List<EventChoice> choices2 = new ArrayList<>();
        EventChoice eventChoice1 = new EventChoice("一份猫粮", new ArrayList<IItem>(Collections.singletonList(new Food(ItemType.CAT_FOOD))),
                "熊熊闻了一下猫粮，显然不感兴趣，又去追击" + decoratedName + "了，" + decoratedName + "下降了10点生命值");
        eventChoice1.setHealthEffect(-10);
        choices2.add(eventChoice1);

        EventChoice eventChoice2 = new EventChoice("一条鱼", new ArrayList<IItem>(Collections.singletonList(new Food(ItemType.FISH))),
                "熊熊闻了一下这条充满腥味的鱼，又望了望快要逃走的" + decoratedName + "，决定还是吃了这条鱼" + decoratedName + "成功逃脱");
        choices2.add(eventChoice2);

        EventChoice eventChoice3 = new EventChoice("一个逗猫棒", new ArrayList<IItem>(Collections.singletonList(new Toy(ItemType.CAT_TICKET))),
                "熊熊看都不看逗猫棒一眼，直接乘胜追击，" + decoratedName + "下降了15点生命值");
        eventChoice2.setHealthEffect(-15);
        choices2.add(eventChoice3);

        EventChoice eventChoice4 = new EventChoice("什么都不留下", null,
                "熊熊直接乘胜追击，" + decoratedName + "下降了15点生命值");
        eventChoice4.setHealthEffect(-15);
        choices2.add(eventChoice4);

        Event event2 = new Event("啊，前面有头熊！", kittenName + "一不小心走到了一头大黑熊的面前，聪明的" +
                decoratedName + "决定逃跑之前留下一件物品来吸引熊熊的注意力，那" + kittenName + "会留下什么作为引诱呢", choices2);
        events.add(event2);

    }

    //已经发生过的事件
    private static List<Event> hasHappened;

    //每次进入探险模式时调用
    public static void init() {
        hasHappened.clear();
    }

    //生成一个随机事件
    public static Event getRandomEvent() {
        Random random = new Random(System.currentTimeMillis());
        int size = events.size();
        Event event = null;
        if (hasHappened.size() == size) {

        }
        do {
            event = events.get(random.nextInt(size));
        } while (hasHappened.contains(event));
        hasHappened.add(event);
        return event;
    }

}
