package com.example.kittenkeeper.explore;

import android.util.Log;

import com.example.kittenkeeper.entity.Kitten;
import com.example.kittenkeeper.entity.Player;
import com.example.kittenkeeper.entity.item.IItem;
import com.example.kittenkeeper.utils.DBUtil;

import java.util.List;


/**
 * 随机事件选项类
 * 每一个随机事件都有多个选项
 */
public class EventChoice {
    public final static String TAG = "EventChoice";
    //选项内容
    private String content;

    //选项需求条件
    private List<IItem> needs;

    //结果内容
    private String result;

    private double happyEffect;

    private double hungryEffect;

    private double intimacyEffect;

    private double healthEffect;

    public boolean canChoose(List<IItem> items) {
        if(items == null || items.size() == 0){
            return needs == null || needs.isEmpty();
        }
        Log.d(TAG, "canChoose: item: " + items + "\nneeds: " +(needs==null? "null":needs));
        return needs == null || needs.isEmpty() || this.containsAllNeeds(items, needs);
    }

    public boolean containsAllNeeds(List<IItem> items, List<IItem> needs){
        for(IItem need :needs){
            boolean flag = false;
            for(IItem item: items){
                if(item.getType() == need.getType()){
                    flag = true;
                    break;
                }
            }
            if(!flag){
                return false;
            }
        }
        return true;
    }

    public void effect(Kitten kitten, Player player, List<IItem> items) {
        if(!canChoose(items)){
            throw new RuntimeException("无法选择该选项，应该先调用canChoose");
        }
        if(items != null && !items.isEmpty() && needs != null){
            items.removeAll(needs);
        }

        kitten = DBUtil.getKitten();
        player = DBUtil.getPlayer();
        kitten.setHappy(kitten.getHappy() + happyEffect);
        kitten.setIntimacy(kitten.getIntimacy() + intimacyEffect);
        kitten.setHungry(kitten.getHungry() + hungryEffect);
        kitten.setHealth(kitten.getHealth() + healthEffect);
        kitten.save();
        player.save();
    }

    public EventChoice(String content, List<IItem> needs, String result) {
        this.content = content;
        this.needs = needs;
        this.result = result;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<IItem> getNeeds() {
        return needs;
    }

    public void setNeeds(List<IItem> needs) {
        this.needs = needs;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public double getHappyEffect() {
        return happyEffect;
    }

    public void setHappyEffect(double happyEffect) {
        this.happyEffect = happyEffect;
    }

    public double getHungryEffect() {
        return hungryEffect;
    }

    public void setHungryEffect(double hungryEffect) {
        this.hungryEffect = hungryEffect;
    }

    public double getIntimacyEffect() {
        return intimacyEffect;
    }

    public void setIntimacyEffect(double intimacyEffect) {
        this.intimacyEffect = intimacyEffect;
    }

    public double getHealthEffect() {
        return healthEffect;
    }

    public void setHealthEffect(double healthEffect) {
        this.healthEffect = healthEffect;
    }

    @Override
    public String toString() {
        return "EventChoice{" +
                "content='" + content + '\'' +
                ", needs=" + needs +
                ", result='" + result + '\'' +
                ", happyEffect=" + happyEffect +
                ", hungryEffect=" + hungryEffect +
                ", intimacyEffect=" + intimacyEffect +
                ", healthEffect=" + healthEffect +
                '}';
    }
}
