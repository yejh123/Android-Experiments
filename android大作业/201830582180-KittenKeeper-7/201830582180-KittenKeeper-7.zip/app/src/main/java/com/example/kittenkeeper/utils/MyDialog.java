package com.example.kittenkeeper.utils;

import android.content.Context;
import android.content.DialogInterface;

import android.widget.EditText;

import androidx.appcompat.app.AlertDialog;

import com.example.kittenkeeper.MainActivity;
import com.example.kittenkeeper.R;
import com.example.kittenkeeper.entity.Kitten;

public class MyDialog {
    public static void showDialog(Context context, String intro, String desc){

        AlertDialog.Builder dialog = new AlertDialog.Builder(context, R.style.dialog);
        dialog.setTitle(intro);
        dialog.setMessage(desc);
        dialog.show();
    }
    /**
     * 修改名字dialog
     */
    public static void showSettingDialog(final Context context) {
        final EditText editText = new EditText(context);
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setIcon(R.mipmap.lxh_idle1);
        Kitten kitten = DBUtil.getKitten();
        builder.setTitle("快给您的猫咪【" + kitten.getName() + "】取一个好听的名字吧");
        //    通过LayoutInflater来加载一个xml的布局文件作为一个View对象
        //View view = LayoutInflater.from(context).inflate(R.layout.sedialog, null);
        //    设置我们自己定义的布局文件作为弹出框的Content
        //builder.setView(view);
        builder.setView(editText);
        editText.setHint("请输入猫咪的新名字");
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = editText.getText().toString().trim();
                if(name.length() == 0) {
                    ToastUtil.showToast(context,"输入内容不能为空哦");
                    return;
                }
                Kitten kitten = DBUtil.getKitten();
                kitten.setName(name);
                kitten.save();
                ToastUtil.showToast(context,"设置成功,猫咪新名字:" + kitten.getName());
            }
        });
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }

}