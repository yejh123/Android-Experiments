package com.example.kittenkeeper.entity;

import org.litepal.annotation.Column;
import org.litepal.crud.LitePalSupport;

import java.util.List;
import java.util.Map;

public class Player extends LitePalSupport {
    @Override
    public String toString() {
        return "Player{" +
                "food=" + food +
                ", heart=" + heart +
                ", money=" + money +
                ", items=" + items +
                '}';
    }

    //食物数量
    @Column(defaultValue = "10")
    private int food;

    //爱心值
    @Column(defaultValue = "80")
    private double heart;

    //金钱
    @Column(defaultValue = "500")
    private int money;

    //物品栏
    private List<Object> items;

    public int getFood() {
        return food;
    }

    public void setFood(int food) {
        this.food = food;
    }

    public double getHeart() {
        return heart;
    }

    public void setHeart(double heart) {
        this.heart = heart;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }
}
