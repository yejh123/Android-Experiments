package com.example.kittenkeeper.entity;

import org.litepal.annotation.Column;
import org.litepal.crud.LitePalSupport;

import java.util.Date;

public class Kitten extends LitePalSupport {
    @Override
    public String toString() {
        return "Kitten{" +
                "name='" + name + '\'' +
                ", hungry=" + hungry +
                ", happy=" + happy +
                ", intimacy=" + intimacy +
                ", health=" + health +
                ", birthDay=" + birthDay +
                ", time=" + time +
                '}';
    }


    private String name;

    //饱食度
    @Column(defaultValue = "100")
    private double hungry;

    //兴奋值
    @Column(defaultValue = "80")
    private double happy;

    //亲密度
    @Column(defaultValue = "0")
    private double intimacy;

    //健康值
    @Column(defaultValue = "100")
    private double health;

    //出生日期
    private Date birthDay;

    //时间
    private Date time;

    public Date getBirthDay() {
        return birthDay;
    }

    public void setBirthDay(Date birthDay) {
        this.birthDay = birthDay;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getHungry() {
        return hungry;
    }

    public void setHungry(double hungry) {
        this.hungry = hungry;
    }

    public double getHappy() {
        return happy;
    }

    public void setHappy(double happy) {
        this.happy = happy;
    }

    public double getIntimacy() {
        return intimacy;
    }

    public void setIntimacy(double intimacy) {
        this.intimacy = intimacy;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }
}
