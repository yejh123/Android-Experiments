package com.example.kittenkeeper.explore;

import com.example.kittenkeeper.entity.item.IItem;

import java.util.List;

/**
 * 探险类
 */
public class Exploration {
    //时长
    private static long duration;

    private static long startTime;

    private static List<IItem> items;

    public static void startExplore(){
        EventFactory.init();

    }

    public static Event getRandomEvent(){
        return EventFactory.getRandomEvent();
    }

    public static void endExplore(){

    }

    public Exploration(long duration, long startTime, List<IItem> items) {
        this.duration = duration;
        this.startTime = startTime;
        this.items = items;
    }

    public static long getDuration() {
        return duration;
    }

    public static void setDuration(long duration) {
        Exploration.duration = duration;
    }

    public static long getStartTime() {
        return startTime;
    }

    public static void setStartTime(long startTime) {
        Exploration.startTime = startTime;
    }

    public static List<IItem> getItems() {
        return items;
    }

    public static void setItems(List<IItem> items) {
        Exploration.items = items;
    }

    @Override
    public String toString() {
        return "Exploration{" +
                "duration=" + duration +
                ", startTime=" + startTime +
                ", items=" + items +
                '}';
    }
}
