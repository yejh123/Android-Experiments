package com.example.kittenkeeper;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.kittenkeeper.explore.Event;
import com.example.kittenkeeper.explore.EventChoice;
import com.example.kittenkeeper.explore.Exploration;
import com.example.kittenkeeper.utils.DBUtil;
import com.example.kittenkeeper.utils.ExploreContent;
import com.example.kittenkeeper.utils.Introduction;
import com.example.kittenkeeper.utils.MyDialog;
import com.example.kittenkeeper.utils.ToastUtil;

import java.util.List;


public class ExploreActivity extends AppCompatActivity implements View.OnClickListener {
    public final static String TAG = "ExploreActivity";

    private Event randomEvent;
    private List<EventChoice> choices= null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        getSupportActionBar().hide();


        TextView viewTitle = (TextView) findViewById(R.id.explore_title);
        TextView viewContent = (TextView) findViewById(R.id.explore_content);


        randomEvent = Exploration.getRandomEvent();
        choices = randomEvent.getChoices();
        viewTitle.setText(randomEvent.getEventTitle());
        viewContent.setText(randomEvent.getEventContent());
        Log.d(TAG, "随机事件: " + randomEvent + "现有物品：" + Exploration.getItems());

        TextView choose1 = findViewById(R.id.choose_1);
        TextView choose2 = findViewById(R.id.choose_2);
        TextView choose3 = findViewById(R.id.choose_3);
        TextView choose4 = findViewById(R.id.choose_4);
        choose1.setText(choices.get(0).getContent());
        choose2.setText(choices.get(1).getContent());
        choose3.setText(choices.get(2).getContent());
        choose4.setText(choices.get(3).getContent());
        choose1.setOnClickListener(this);
        choose2.setOnClickListener(this);
        choose3.setOnClickListener(this);
        choose4.setOnClickListener(this);

    }


    @Override
    public void onClick(View view) {
        int choose = 0;
        switch (view.getId()){
            case R.id.choose_1:
                choose = 0;
                break;
            case R.id.choose_2:
                choose = 1;
                break;
            case R.id.choose_3:
                choose = 2;
                break;
            case R.id.choose_4:
                choose = 3;
                break;
        }
        if(choices.get(choose).canChoose(Exploration.getItems())){
            choices.get(choose).effect(DBUtil.getKitten(), DBUtil.getPlayer(), Exploration.getItems());
            showNormalDialog(choices.get(choose).getContent(), choices.get(choose).getResult());

        }else{
            ToastUtil.showToast(ExploreActivity.this, "无法选择这个选项哦");
        }
    }

    private void showNormalDialog(String title, String content){
        /* @setIcon 设置对话框图标
         * @setTitle 设置对话框标题
         * @setMessage 设置对话框消息提示
         * setXXX方法返回Dialog对象，因此可以链式设置属性
         */
        final AlertDialog.Builder normalDialog =
                new AlertDialog.Builder(ExploreActivity.this);
        normalDialog.setIcon(R.mipmap.lxh_idle1);
        normalDialog.setTitle(title);
        normalDialog.setMessage(content);
        normalDialog.setCancelable(false);
        normalDialog.setPositiveButton("确定",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //...To-do
                        Intent intent = new Intent(ExploreActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
                        startActivity(intent);
                    }
                });
        normalDialog.setNegativeButton("关闭",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //...To-do
                        Intent intent = new Intent(ExploreActivity.this, MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY);
                        startActivity(intent);
                    }
                });
        // 显示
        normalDialog.show();
    }
}
