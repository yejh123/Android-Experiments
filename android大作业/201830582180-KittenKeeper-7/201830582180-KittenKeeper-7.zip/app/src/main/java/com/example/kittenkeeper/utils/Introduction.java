package com.example.kittenkeeper.utils;

public class Introduction {
    public static String HUNGRY_INTRODUCTION = "饱食度";
    public static String HAPPY_INTRODUCTION = "兴奋值";
    public static String INTIMACY_INTRODUCTION = "亲密度";
    public static String HEART_INTRODUCTION = "健康值";
    public static String TIP_INTRODUCTION = "我家猫咪大养成";

    public static String HUNGRY_DESCRIPTION = "每过一段时间猫咪会下降一点饱食度，饱食度处于过低状态后会逐渐降低健康值，并会提示主人来喂食，" +
            "如果主人未及时喂食亲密度和健康值会迅速下降。喂食可以提高饱食度。";
    public static String HAPPY_DESCRIPTION = "兴奋值即宠物的活跃度，活跃度越高，猫咪“说话”越频繁（后续会推出相关功能）" +
            "通过与猫咪的互动可以提高兴奋值，兴奋值会随时间下降，兴奋值越高，一定程度上亲密度增加越快。";
    public static String INTIMACY_DESCRIPTION = "亲密度代表你和宠物之间的亲密程度。亲密度越高，" +
            "亲密度会随互动和时间而增加";
    public static String HEART_DESCRIPTION = "健康值表示宠物的健康程度。健康值过低，宠物将面临死亡的危险";
    public static String TIP_DESCRIPTION = "这是一款以猫咪养成+探险为主要玩法的app，您可以与您的爱猫进行玩耍，同时也需要花时间去" +
            "给ta喂食、治疗，并且还可以带ta出去探险哦！赶快开始您的猫咪养成之旅吧！";

}