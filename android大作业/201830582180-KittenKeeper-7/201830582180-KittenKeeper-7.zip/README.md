# 我家猫咪大养成

## 简介
这是一款以猫咪养成+探险为主要玩法的app，您可以与您的爱猫进行玩耍，同时也需要花时间去给ta喂食、治疗，并且还可以带ta出去探险哦！赶快开始您的猫咪养成之旅吧！

### 玩法介绍
1. 在“家”中和猫咪互动
   + 对话框（猫咪会说话，此时在页面弹出对话框，玩家可以选择对话选项）
   + 笑抚~~狗头~~猫头
   + 喂食play
   + 玩耍
   + 拖动猫咪 ~~(把猫咪拖到屏幕顶端让其做自由落体)~~
   + 改名
   + 升级领新装扮（敬请期待）
   
2. 探险
   + 选择探险将要携带的物品
   + 遭遇随机事件
   + 选择对策
   
---
### 项目需求
1. 猫咪状态
   + 饱食度<br/>
   每过？分钟会下降一点饱食度，饱食度低于20%后提示主人来喂食<br/>
   喂食可以提高饱食度<br/>
   + 兴奋值（活跃度）<br/>
   活跃度越高，猫咪“说话”越频繁（没错，这是一只会说法的猫咪）<br/>
   通过与猫咪的互动可以提高兴奋值，兴奋值会随时间下降<br/>
   猫咪~~达到高潮~~兴奋值达到100%会有特殊动画<br/>
   + 亲密度<br/>
   亲密度会随时间而增加<br/>
   
   
2. 玩家状态
   + 食物数量<br/>
   每天会有食物自动派发<br/>
   + 爱心值<br/>
   良好的互动会提高玩家爱心值，恶劣的互动（比如~~虐猫~~做自动落体）会降低玩家爱心值<br/>
   
3. “家”的界面
   + 背景图
   + 状态展示icon
   + 触摸
   + 喂食
   + 拖动
   + 对话框
   + 动画
   
---
### 需求分析
#### 打开app
   + 授权：暂无
   + 如果服务没开启，则开启后台服务
   + 数据初始化<br/>
   从后台拿到最近时刻状态的饱食度、亲密度、兴奋值等数据进行页面渲染
   
   
 #### 用户交互
   + 喂食<br/>
   点击左下角的“食物”图标，播放喂食动画，动画播放完后饱食度提高（暂定60%）
   + 玩耍<br/>
   点击“猫咪”，会在猫咪头顶上出现“玩耍”图标，再点击“玩耍”图标，会播放玩耍动画，结束后提高兴奋值（暂定10点，上限100），亲密度（暂定1点，每日最多10点，上不封顶），爱心值（暂定1点，每日最多提高2点，上不封顶）
   + 获取食物<br/>
   待定，测试阶段设置食物量为无限
   
   
 #### 关闭app
   + 更新状态<br/>
   往kitten表中，添加一条最新记录（kitten表中不只一条记录）<br/>
   更新player表中唯一一条记录
   
 #### 后台服务
   + 饱食度随时间减低（暂定每6分钟下降1点）
   + 亲密度随闲置时间而降低<br/>
   距离上次关闭app每2小时下降1点
   + 兴奋值随闲置时间而降低<br/>
   距离上次和猫咪玩耍每过10分钟下降1点
   + 通知
   当饱食度低于30%或者兴奋值低于10%时，会发送通知，告知用户记得给猫咪喂食或者玩耍
   
---
### 开发难题
   + 如何实现动画：https://blog.csdn.net/carson_ho/article/details/79860980
   + ConstraintLayout布局：https://blog.csdn.net/guolin_blog/article/details/53122387
   + 使用LitePal数据库：https://github.com/LitePalFramework/LitePal
   
<hr/>
### 开发步骤
   + 数值设计（游戏策划）<br/>
   爱心值怎么加，饱食度怎么掉？饱食度空了会怎样？
   + 数据获取（爱心值、饱食度等等）<br/>
   操作数据库
   + 动作动画设计（画图）
   + 动画实现（写代码）
   + 探险小游戏
   + 背景音乐和音效
   + 猫咪对话（人猫智能？）<br/>
   可以尝试调用人工智能对话相关接口
   + 彩蛋设计<br/>
   比如猫咪突然说一句sh150？
   + 实现桌面小精灵功能<br/>
   如果时间充裕，可以在桌面上也可以实现和猫咪互动 ~~(肯定没时间)~~

---
### 实体类设计
#### Kitten类
```
 public class Kitten extends LitePalSupport {
    //单例设计模式，因为只有一只猫
    private static Kitten kitten;

    @Column(defaultValue = "lovely kitten")
    private String name;

    //饱食度
    @Column(defaultValue = "100")
    private double hungry;

    //兴奋值
    @Column(defaultValue = "100")
    private double happy;

    //亲密度
    @Column(defaultValue = "0")
    private double intimacy;

    //健康值
    @Column(defaultValue = "100")
    private double health;

    //出生日期
    private Date birthDay;

    //时间
    private Date time;
 }
```
#### Player类
```
public class Player extends LitePalSupport {
    //单例设计模式，因为只有一个玩家
    private static Player player;

    //食物数量
    @Column(defaultValue = "10")
    private int food;

    //爱心值
    @Column(defaultValue = "80")
    private double heart;

    //金钱
    @Column(defaultValue = "500")
    private int money;

    //物品栏
    private List<Object> items;
}
```

#### IItem接口
```
public interface IItem {
    String getItemName();

    String getItemDescription();

    void useItem();
}
```



